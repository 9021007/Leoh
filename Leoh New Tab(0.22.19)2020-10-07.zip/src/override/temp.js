    // var nameTextbox = document.getElementById("nameTextbox").value;

    // chrome.storage.sync.get('textIT', function(result) {
    //     textIT = result.textIT;
    //     $("#nameTextbox").val(textIT);
        // 		$("#greetingTextbox").keypress(function (e) {
        //     if (e.keyCode == 13) {
        //     	var nameTextboxSave = document.getElementById("nameTextbox").value;
        // 			chrome.storage.sync.set({'textIT': nameTextboxSave});
        //     	document.getElementById("nameTextbox").value = document.getElementById("greetingTextbox").value;
        //     	document.getElementById("greeting").innerHTML="Today<br><div id='taskDoneCheckmark'><i class='fa fa-check'></i></div><label id='taskOfDay'>"+document.getElementById('nameTextbox').value+"<div id='taskIcons'><i id='removeCross' class='fa fa-times'></i><br><i id='doneCheck' class='fa fa-check'></i></div></label>";
        //     	$('#doneCheck').click(function(){
        //     		if (document.getElementById('taskDoneCheckmark').style.visibility === 'visible') {
        //     			document.getElementById('taskDoneCheckmark').style.visibility = 'hidden';
        //     		} else {
        //     			document.getElementById('taskDoneCheckmark').style.visibility = 'visible';
        //     		}
        // 		});
        // 		$('#removeCross').click(function(){
        // 			document.getElementById('nameTextbox').value = "";
        // 			var nameTextboxSave = document.getElementById("nameTextbox").value;
        // 			chrome.storage.sync.set({'textIT': nameTextboxSave});
        // 		});
        //     }
        // });
        // 	} else {
        //     	document.getElementById("greeting").innerHTML="Today<br><div id='taskDoneCheckmark'><i class='fa fa-check'></i></div><label id='taskOfDay'>"+document.getElementById('nameTextbox').value+"<div id='taskIcons'><i id='removeCross' class='fa fa-times'></i><br><i id='doneCheck' class='fa fa-check'></i></div></label>";
        //     	$('#doneCheck').click(function(){
        //     		if (document.getElementById('taskDoneCheckmark').style.visibility === 'visible') {
        //     			document.getElementById('taskDoneCheckmark').style.visibility = 'hidden';
        //     		} else {
        //     			document.getElementById('taskDoneCheckmark').style.visibility = 'visible';
        //     		}
        // 		});
        // 		$('#removeCross').click(function(){
        // 			document.getElementById('nameTextbox').value = "";
        // 			var nameTextboxSave = document.getElementById("nameTextbox").value;
        // 			chrome.storage.sync.set({'textIT': nameTextboxSave});
        // 		});
        // 	}
    // });